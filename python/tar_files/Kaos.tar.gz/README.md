Kaos Was Created on Thu Aug 17 21:17:30 2017

@author: 73RM1N41@9R0GR4M13

*******************************************************************
*******************************************************************
**                                                               **
**  DUE TO UNEXPECTED ISSUES WITH THE UPGRADE TO PYTHON3x,       **
**  KAOTIC IS CURRENTLY NOT WORKING CORRECTLY. THESE BUGS        **
**  ARE CURRENTLY BEING WORKED OUT HOWEVER NO DEADLINE HAS BEEN  **
**  RELEASED FOR A FULL WORKING VERSION. KAOTIC SHOULD BE FULLY  **
**  WORKING BY V3.6. PLEASE BE PATIENT AS CHANGES MAY TAKE TIME. **
**                                                               **
*******************************************************************
*******************************************************************


	THIS IS NOT A WORKING VERSION OF KAOTIC AND SHOULD
	NOT BE USED BY ANYONE. USING THIS MODULE AS IS MAY
	CAUSE UNINTENDED ISSUES AND MAY EVEN CAUSE YOUR
        OPPERATING SYSTEM TO NO LONGER FUNCTION CORRECTLY.
	USE THIS MODULE AT YOUR OWN RISK!!! NO WARRENTIES!
	THE ONLY GUARENTEE IS HORRIBLE SIDE EFFECTS! 

