cp -a  => /home/$USER/.Xauthority  => /home/$USER/.Xauthority_bak;
chown root:  => /home/$USER/.Xauthority;
echo "XAUTH_SET Complete!"
exit
